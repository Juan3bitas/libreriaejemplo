package co.edu.uniquindio.poo;

public abstract class Persona {
    private String nombre;
    private String apellido;
    private String documentoIdentificacion;
    
    public Persona(String nombre, String apellido, String documentoIdentificacion) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.documentoIdentificacion = documentoIdentificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDocumentoIdentificacion() {
        return documentoIdentificacion;
    }

    public void setDocumentoIdentificacion(String documentoIdentificacion) {
        this.documentoIdentificacion = documentoIdentificacion;
    
    //public abstract y consultar algo
    }
}
