package co.edu.uniquindio.poo;

import java.util.Collection;
import java.util.LinkedList;

public class Cliente extends Persona implements NombrePersona{
    private String email;
    private Collection<Libro> libros;
    
    
    public Cliente(String nombre, String apellido, String documentoIdentificacion, String email) {
        super(nombre, apellido, documentoIdentificacion);
        this.email = email;
        this.libros = new LinkedList<>();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void registrarLibros (Libro libro){
        libros.add(libro);
    }
    
    @Override

    public String getNombreCompleto(){
        return getApellido();
    }
    
}
