package co.edu.uniquindio.poo;

import java.util.Collection;
import java.util.LinkedList;

public class Libreria {
    private String nombre;
    private Collection<Libro> libros;
    private Collection<Persona> personas;

    public Libreria(String nombre) {
        this.nombre = nombre;
        this.libros = new LinkedList<>();
        this.personas = new LinkedList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void registrarLibro(Libro libro){
        libros.add(libro);
    }

    public void registrarPersonas(Persona persona){
        personas.add(persona);
    }
}
