package co.edu.uniquindio.poo;

public class Empleado extends Persona implements NombrePersona{
    private String telefono;

    public Empleado(String nombre, String apellido, String documentoIdentificacion, String telefono) {
        super(nombre, apellido, documentoIdentificacion);
        this.telefono = telefono;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    @Override

    public String getNombreCompleto(){
        return getNombre() + " " + getApellido();
    }
    
}
