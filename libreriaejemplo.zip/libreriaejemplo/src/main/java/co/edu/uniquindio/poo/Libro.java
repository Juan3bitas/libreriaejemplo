package co.edu.uniquindio.poo;

public class Libro {
    private String nombre;
    private String autor;
    private int edicion;
    private String isbn;
    private int paginas;
    
    public Libro(String nombre, String autor, int edicion, String isbn, int paginas) {
        this.nombre = nombre;
        this.autor = autor;
        this.edicion = edicion;
        this.isbn = isbn;
        this.paginas = paginas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getEdicion() {
        return edicion;
    }

    public void setEdicion(int edicion) {
        this.edicion = edicion;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

}
