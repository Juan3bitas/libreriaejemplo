package co.edu.uniquindio.poo;

import java.util.Collection;
import java.util.LinkedList;

public class LibroMalHecho {

    public class Libro {
    private String nombre;
    public String autor;
    public int edicion;
    private int paginas;
    private Collection<Cliente> clientes;

    public Libro(String nombre, String autor, int edicion, int paginas) {
        this.nombre = nombre;
        this.autor = autor;
        this.edicion = edicion;
        this.paginas = paginas;
        this.clientes = new LinkedList<>();
    }
    public void registrarLibro(){
    }

    //Principio del Single Use Responsability NO aplicado:

    //Basandonos en lo que dicta el Single Use Responsability, el código no cumple con este principio
    //esto, porque se agregó el método registrarLibro a la clase Libro, cuando la unica responsabilidad de esta clase
    //debe ser crearLibro, y la responsabilidad de Libreria sí debe registrarLibro.
    public String getNombre() {
        return nombre;
    }
    public void registrarClientes(Cliente cliente){
        clientes.add(cliente);
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getEdicion() {
        return edicion;
    }

    public void setEdicion(int edicion) {
        this.edicion = edicion;
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

}


}

