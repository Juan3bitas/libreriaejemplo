package co.edu.uniquindio.poo;

public interface NombrePersona {
    String getNombreCompleto();
}
